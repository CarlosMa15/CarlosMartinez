package balloon;

public enum Size { 
	XS, S, M, L, XL

}
