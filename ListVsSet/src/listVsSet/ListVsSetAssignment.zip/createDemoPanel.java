/*************************************
 * Author: Carlos Martinez
 * Date: March 9, 2017
 * Assignment: ListVsSet
 ************************************/
package listVsSet;

/**
 * This class does nothing but create one of the panels in
 * the ListVsSetGui class 
 * @author carlosmartinez
 */
public class createDemoPanel {
	// This class for the most part does nothing
}